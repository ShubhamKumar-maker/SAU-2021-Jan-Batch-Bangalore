import { Component, Input, OnInit } from '@angular/core';
import { Word } from '../Models/Words';
import { WordService } from '../word.service';

@Component({
  selector: 'app-search-word',
  templateUrl: './search-word.component.html',
  styleUrls: ['./search-word.component.scss']
})
export class SearchWordComponent implements OnInit {
  searchword:Array<Word>=[];
  text:string="";
  word:Array<Word>=[];
  meaning:String="";
 

  constructor(private wordService:WordService) { }

  ngOnInit(): void {
    this.wordService.getALL().subscribe(words=>{
      this.searchword=words;
    })
    
  }

  onKeyUp(x:any) {
    if(x.keyCode === 13){
    this.text = x.target.value; 
      this.searchword.forEach(element => {
        var str = element.word;
        var patt = new RegExp(this.text);
         if(patt.test(str)){
        this.word.push(element);
         }
    });
  }
  else if(x.keyCode === 8)
  {
    this.word=[];
  }
  } 
 

}

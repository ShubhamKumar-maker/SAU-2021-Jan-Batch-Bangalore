import { Component, OnInit } from '@angular/core';
import { WordService } from '../word.service';
import {Word} from '../Models/Words'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  words:Array<Word>=[];
  editableWord!: Word;
 
 
  constructor(private wordService:WordService) { 

    
      
  }

  ngOnInit(): void {

    this.wordService.getALL().subscribe(words=>{
      this.words=words;
    })
    
  }

  edit(word:Word):void
{
  this.editableWord = word;
 // console.log("edit",word);
  console.log(this.editableWord);
  

}

delete(word:Word):void
{
  this.wordService.deleteWord(word.id).subscribe(req=>{
    console.log(req);
    if(req)
    {
      this.words=this.words.filter(oldword=>word.id!=oldword.id)
    }
  })
}


updateWord($event:any): void {
 this.words.forEach(element => {
        if(element.id==undefined||element.id==$event.id)
        {
          element.id=$event.id;
          element.word=$event.word;
          element.meaning=$event.meaning;
          element.partOfSpeech=$event.partOfSpeech;
          element.example=$event.example;
        }    
  });

}
key:String='id';
reverse:boolean=false;
sort1(key:String)
{
  this.key=key;
  this.reverse=!this.reverse;
}
sort2(key:String)
{
  this.key=key;
  this.reverse=!this.reverse;
}


}

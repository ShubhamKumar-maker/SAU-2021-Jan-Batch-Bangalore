import { Component, EventEmitter ,Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Word } from '../Models/Words';
import { WordService } from '../word.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.scss']
})
export class UpdateComponent implements OnInit, OnChanges {
  // tslint:disable-next-line: no-input-rename
  @Input('action') buttonLabel: string="" ;
  // tslint:disable-next-line: no-input-rename
  @Input('editableData') editableData: any;
  @Output() updateWord = new EventEmitter<any>();
    wordForm!: FormGroup;
    addWordPayload!: Word ;
    id!: number ;
  constructor(private wordService: WordService)
  {
  //   this.wordForm=new FormGroup({ 
  //     word: new FormControl(null,[Validators.required,Validators.minLength(2),Validators.maxLength(50)]),
  //     meaning:new FormControl(null,[Validators.required,Validators.minLength(10),Validators.maxLength(150)]),
  //     partOfSpeech: new FormControl(null,[Validators.required]),
  //     example: new FormControl(null,[Validators.required]),
  // })
  }

  ngOnInit(): void {
    this.wordForm = new FormGroup({
      word: new FormControl(null, [Validators.required, Validators.minLength(2), Validators.maxLength(50)]),
      meaning: new FormControl(null, [Validators.required, Validators.maxLength(150), Validators.minLength(10)]),
      partOfSpeech: new FormControl(null, [Validators.required]),
      example: new FormControl(null, [Validators.required]),
    });

  }
  addOrUpdateWord(): void{
    this.addWordPayload = this.wordForm.value;
    if (this.buttonLabel.includes('Update')) {
      this.updateWord.emit({
        ...this.wordForm.value,
        id: this.id,
    });
    } else {
      this.wordService.addWord(this.addWordPayload).subscribe(resp => {
        console.log(resp);
      });
    }
    // this.addWordPayload.id=null;
    // this.addWordPayload.creationTm=null;
    // this.addWordPayload.lastModifiedTm=null;
  }
  ngOnChanges(changes:any) {
   // console.log(this.editableData);
    if (changes.editableData && changes.editableData.currentValue != changes.editableData.previousValue) {
      this.id = this.editableData.id;
      delete this.editableData.id;
      delete this.editableData.creationTm;
      delete this.editableData.lastModifiedTm;
      this.wordForm.setValue(this.editableData);
      // console.log(this.editableData); 
   }
  }


}

import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import { Observable } from 'rxjs';
import {Word} from "./Models/Words";
@Injectable({
  providedIn: 'root'
})
export class WordService {

  Get_ALL_WORDS="/word/getAll";
  SAVE_WORD="/word/save";
  DELETE_WORD="/word/delete/";
  constructor(private http:HttpClient) { }

  getALL():Observable<any>{
    return this.http.get(this.Get_ALL_WORDS)
  }

  addWord(payload:Word):Observable<any>
  {
    return this.http.post(this.SAVE_WORD,payload);
  }

  deleteWord(id:Number):Observable<any>
  {
return this.http.get(this.DELETE_WORD+id);
  }
}

package com.demo.Dictionary.services;

import java.util.List;

import com.demo.Dictionary.entities.Word;

public interface IWordService {
	
	public Word save(Word word);

	public List<Word> getAll();
	
	public boolean delete(int id);

	public Word update(Word word, int id);

	public List<Word> getAllSorted();

}

package com.demo.Dictionary.curd.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.Dictionary.dao.IWordDao;
import com.demo.Dictionary.entities.Word;
import com.demo.Dictionary.services.IWordService;

@Service
public class WordService  implements IWordService {

	@Autowired
	IWordDao iWordDao;
	@Override
	public Word save(Word word) {
		return iWordDao.save(word);
	}
	
	public List<Word> getAll() {
		return iWordDao.getAll();
	}
	
	@Override
	public boolean delete(int id) {
		int rowsAffected = iWordDao.delete(id);
		if (rowsAffected == 1) {
			return true;
		}
		return false;
	}

	@Override
	public Word update(Word word, int id) {
		// TODO Auto-generated method stub
		return iWordDao.update(word,id);
	}

	@Override
	public List<Word> getAllSorted() {
		// TODO Auto-generated method stub
		return iWordDao.getAllSorted();
	}


}

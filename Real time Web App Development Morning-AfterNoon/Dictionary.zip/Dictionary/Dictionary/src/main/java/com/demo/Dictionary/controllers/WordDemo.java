package com.demo.Dictionary.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.Dictionary.entities.Word;
import com.demo.Dictionary.services.IWordService;



@RestController	
@RequestMapping("word")
public class WordDemo {
	
	@Autowired
	IWordService iWordService;
	
@PostMapping("/save")
	public Word save(@RequestBody Word word) {
		return iWordService.save(word);

}

@GetMapping("/getAll")
public List<Word> getAll() {
	return iWordService.getAll();
}
	

@GetMapping("/test")
public String test() {
	
	return "Success";
}

@GetMapping("/delete/{id}")
public boolean getAll(@PathVariable int id) {
	return iWordService.delete(id);
}

@PutMapping("/update/{id}")
public Word update(@RequestBody Word word,@PathVariable int id)
{
	return iWordService.update(word,id);
}

@GetMapping("/getAllSorted")
public List<Word> getAllSorted() {
	return iWordService.getAllSorted();
}



}

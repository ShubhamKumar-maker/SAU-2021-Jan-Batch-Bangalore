package com.demo.Dictionary.controllers;

import org.springframework.stereotype.Controller;

@Controller
public class DemoController {
	
	
}

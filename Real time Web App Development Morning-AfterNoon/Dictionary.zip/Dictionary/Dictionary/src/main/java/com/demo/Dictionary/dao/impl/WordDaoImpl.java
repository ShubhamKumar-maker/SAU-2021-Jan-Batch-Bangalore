package com.demo.Dictionary.dao.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.demo.Dictionary.dao.IWordDao;
import com.demo.Dictionary.entities.Word;
import com.demo.Dictionary.queries.WordQueries;
import com.demo.Dictionary.table.contants.WordTableConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Repository
public class WordDaoImpl implements IWordDao{
	
	private static Logger logger = LoggerFactory.getLogger(WordDaoImpl.class);
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public Word save(Word word) {
		final KeyHolder holder = new GeneratedKeyHolder();
		String sql = "INSERT INTO WORDS ( WORD , MEANING , PART_OF_SPEECH , EXAMPLE , CREATION_TM , LAST_MODIFIED_TM ) "
				+ " VALUES ( :WORD , :MEANING , :PART_OF_SPEECH , :EXAMPLE , :CREATION_TM , :LAST_MODIFIED_TM )";
		MapSqlParameterSource srcMap = new MapSqlParameterSource();
		srcMap.addValue("WORD", word.getWord());
		srcMap.addValue("MEANING",word.getMeaning());
		srcMap.addValue("PART_OF_SPEECH",word.getPartOfSpeech());
		srcMap.addValue("EXAMPLE",word.getExample());
		srcMap.addValue("CREATION_TM",word.getCreationTm());
		srcMap.addValue("LAST_MODIFIED_TM",word.getLastModifiedTm());
		
		namedParameterJdbcTemplate.update(sql, srcMap,
		        holder, new String[] {"ID"});
		word.setId(holder.getKey().intValue());
		return word;
	}
	
	@Override
	public List<Word> getAll() {
		String sql = " SELECT * FROM WORDS ";
		return namedParameterJdbcTemplate.query(sql, (resultSet, rowNum) -> {
			Word word = new Word();
			word.setId(resultSet.getInt("ID"));
			word.setCreationTm(resultSet.getDate("CREATION_TM"));
			word.setExample(resultSet.getString("EXAMPLE"));
			word.setLastModifiedTm(resultSet.getDate("LAST_MODIFIED_TM"));
			word.setMeaning(resultSet.getString("MEANING"));
			word.setPartOfSpeech(resultSet.getString("PART_OF_SPEECH"));
			word.setWord(resultSet.getString("WORD"));
			return word;
		});
	}
	
	@Override
	public int delete(int id) {
		logger.info(WordQueries.DELETE_QUERY);
		MapSqlParameterSource srcMap = new MapSqlParameterSource();
		srcMap.addValue(WordTableConstants.ID, id);
		return namedParameterJdbcTemplate.update(WordQueries.DELETE_QUERY, srcMap);
	}

	@Override
	public Word update(Word word, int id) {
//		List<Word>list=new ArrayList<>();
//		list.stream().map(w->{
//			if(w.getId()==id)
//			{
//			w.setWord(word.getWord());
//			w.setExample(word.getExample());
//			w.setMeaning(word.getMeaning());
//			w.setPartOfSpeech(word.getPartOfSpeech());
//			w.setCreationTm(word.getCreationTm());
//			w.setLastModifiedTm(word.getLastModifiedTm());
//			}
//			
//			return w;
//		}).collect(Collectors.toList());
//		return null;
//		String sql="UPDATE WORDS SET WORD=:WORD, MEANING=:MEANING  , PART_OF_SPEECH=:PART_OF_SPEECH , EXAMPLE=:EXAMPLE , CREATION_TM=:CREATION_TM , LAST_MODIFIED_TM=:LAST_MODIFIED_TM  WHERE WORDS.ID=:ID";
//		MapSqlParameterSource srcMap = new MapSqlParameterSource();
//		srcMap.addValue("WORD", word.getWord());
//		srcMap.addValue("MEANING",word.getMeaning());
//		srcMap.addValue("PART_OF_SPEECH",word.getPartOfSpeech());
//		srcMap.addValue("EXAMPLE",word.getExample());
//		srcMap.addValue("CREATION_TM",word.getCreationTm());
//		srcMap.addValue("LAST_MODIFIED_TM",word.getLastModifiedTm());
//		srcMap.addValue("ID", id);
//		namedParameterJdbcTemplate.update(sql,srcMap);
		logger.info(WordQueries.UPDATE_QUERY);
		MapSqlParameterSource srcMap = new MapSqlParameterSource();
		srcMap.addValue(WordTableConstants.ID, id);
		srcMap.addValue(WordTableConstants.WORD, word.getWord());
		srcMap.addValue(WordTableConstants.MEANING,word.getMeaning());
		srcMap.addValue(WordTableConstants.POS,word.getPartOfSpeech());
		srcMap.addValue(WordTableConstants.EXAMPLE,word.getExample());
		srcMap.addValue(WordTableConstants.CREATION_TM,word.getCreationTm());
		srcMap.addValue(WordTableConstants.LAST_MODIFIED_TM,word.getLastModifiedTm());
		namedParameterJdbcTemplate.update(WordQueries.UPDATE_QUERY, srcMap);
		
		
		
		return word;
	}

	@Override
	public List<Word> getAllSorted() {
		String sql = " SELECT * FROM WORDS ORDER BY ID DESC";
		return namedParameterJdbcTemplate.query(sql, (resultSet, rowNum) -> {
			Word word = new Word();
			word.setId(resultSet.getInt("ID"));
			word.setCreationTm(resultSet.getDate("CREATION_TM"));
			word.setExample(resultSet.getString("EXAMPLE"));
			word.setLastModifiedTm(resultSet.getDate("LAST_MODIFIED_TM"));
			word.setMeaning(resultSet.getString("MEANING"));
			word.setPartOfSpeech(resultSet.getString("PART_OF_SPEECH"));
			word.setWord(resultSet.getString("WORD"));
			return word;
		});
	}

}

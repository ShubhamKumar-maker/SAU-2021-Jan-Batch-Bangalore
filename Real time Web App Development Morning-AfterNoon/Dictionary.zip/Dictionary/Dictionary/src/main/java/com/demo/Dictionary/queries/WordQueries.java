package com.demo.Dictionary.queries;

import com.demo.Dictionary.table.contants.WordTableConstants;

public class WordQueries {
	
	private WordQueries() {

	}

	public static final String DELETE_QUERY = "DELETE FROM " + WordTableConstants.TABLE_NAME + " WHERE "
			+ WordTableConstants.ID + " =:" + WordTableConstants.ID;
	
	public static final String UPDATE_QUERY="UPDATE "+ WordTableConstants.TABLE_NAME +" SET "+
			WordTableConstants.WORD + " =:" + WordTableConstants.WORD + ","+
			WordTableConstants.EXAMPLE + " =:" + WordTableConstants.EXAMPLE + ","+
			WordTableConstants.POS + " =:" + WordTableConstants.POS + ","+
			WordTableConstants.MEANING + " =:" + WordTableConstants.MEANING + ","+
			WordTableConstants.CREATION_TM + " =:" + WordTableConstants.CREATION_TM + ","+
			WordTableConstants.LAST_MODIFIED_TM + " =:" + WordTableConstants.LAST_MODIFIED_TM
			+ " WHERE "
			+ WordTableConstants.ID + " =:" + WordTableConstants.ID;
}

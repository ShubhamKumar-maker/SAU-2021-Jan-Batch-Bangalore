package com.demo.Dictionary.dao;

import java.util.List;

import com.demo.Dictionary.entities.Word;

public interface IWordDao {
	
public	Word save(Word word);

public List<Word> getAll();

public int delete(int id);

public Word update(Word word, int id);

public List<Word> getAllSorted();



}

import React,{useState, useEffect} from 'react';

import AsyncStorage  from '@react-native-community/async-storage';
import { ImageBackground,TouchableOpacity,Button, StyleSheet, Text, View,Platform} from 'react-native';
import { TextInput } from 'react-native-gesture-handler';
import { greaterThan } from 'react-native-reanimated';


const image = { uri: "https://images.pexels.com/photos/586744/pexels-photo-586744.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" };


export default function Login({navigation}) {
  const [username, setUserName] = useState("");

  useEffect(() => {
    checkAuth()
})

const checkAuth = async () => {
const userName = await AsyncStorage.getItem("username");
  if (userName) {
      navigation.navigate("Dashboard");
  }
  return ;
}
  

const handler= async ()=>{
  try{
  await AsyncStorage.setItem("username",username);
  
      console.log('data successfuly save')
  navigation.navigate('Dashboard');
  }
  catch(e)
  {
    console.log('failed to save');
  }
}


  return (
    <ImageBackground source={image} style={Styles.image} blurRadius={ Platform.OS == 'ios' ? 10 : 5 } >
    <View style={Styles.mainContainer}>
      
      <Text style={Styles.heading}>Login</Text>
      
      <TextInput style={Styles.inputbox} placeholder="Enter User Name" onChangeText={(text) => setUserName(text)}></TextInput>
      <TouchableOpacity style={Styles.button1} onPress={handler}><Text style={Styles.button1Text}> Go to Next </Text></TouchableOpacity>
      
    </View>
    </ImageBackground>
    
  );
}


const Styles = StyleSheet.create({
  mainContainer: {
     flex:1,
     flexDirection: 'column',
     justifyContent: 'center',
     
     paddingVertical: 8,
    borderWidth: 4,
    
    },
    heading:{
      textAlign: "center",
      fontSize: 30,
      fontWeight: "bold",
      marginBottom:50,
      
    
    },
    inputbox:{
    
      margin: 20,
      height: 40,
      borderColor: '#FF6347',
      borderWidth: 1,
      borderRadius:3,
      padding:10,
      color:"white"

    },
    button1:{
      
      backgroundColor: '#FF6347',
      padding:10,
      margin: 15,
      height: 40,
      borderRadius:4
     

    },
    button1Text:{
      textAlign:'center',
      color: 'white'
   },
   image: {
    
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    
  }






})
import React,{useState} from 'react';
import { TouchableOpacity, Button, StyleSheet, Text, View } from 'react-native';
import { TextInput } from 'react-native-gesture-handler';
import { useEffect } from 'react/cjs/react.development';

export default function AddList({navigation}) {



  const[utitle,settitle]=useState(null);
  const[udiscription,setdiscription]=useState(null);




  
  return (
    <View style={Styles.views}>
      <TextInput style={Styles.text1} placeholder="Enter Title" onChangeText={(text) => settitle(text)}></TextInput>
      <TextInput style={Styles.text2} placeholder="Enter Discription" onChangeText={(text) => setdiscription(text)}></TextInput>
      <TouchableOpacity style={Styles.button1} onPress={()=>{navigation.navigate('Dashboard',{title:utitle,discription:udiscription})}}><Text style={Styles.button1Text}>Add Data</Text></TouchableOpacity>
  
    </View>
  );
}

const Styles=StyleSheet.create({

  views:{
    flex:1,
     flexDirection: 'column',
     justifyContent: 'center',
     backgroundColor:'#585656',
     paddingVertical: 8,
    borderWidth: 4,

  },

  text1:{
    margin:10,
    borderWidth:1,
    paddingLeft:5,
    borderColor: '#FF6347',
    height:40,
    color:'white'

    
    

  },
  text2:{
    margin:10,
    height:100,
    borderWidth:1,
    alignItems:'center',
    paddingLeft:5,
    borderColor: '#FF6347',
    color:'white'

  },
  button1:{
    margin:10,
    height:50,
    width:70,
    backgroundColor:'#FF6347',
    alignSelf: 'flex-end',
    alignItems:'center',
    justifyContent: 'center',
    borderRadius:10
    

  },
  button1Text:{
    color:'white'
    

  }


})
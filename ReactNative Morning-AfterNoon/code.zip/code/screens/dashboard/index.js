import React,{useState,useEffect} from 'react';
import { TouchableOpacity,ScrollView,SafeAreaView,StyleSheet, Text, View,FlatList, Button } from 'react-native';

export default function Dashboard({navigation}) {


const [update,setupdate]=useState([]);


 const [notedata,setnote]=useState([]);





//delete data
const removeTask = index => {
  const newTasks = [...notedata];
  newTasks.splice(index, 1);
  setnote(newTasks);
  console.log(index);
  
};


const [ntitle,settitle]=useState(navigation.getParam('title'));
const [ndiscription,setdiscription]=useState(navigation.getParam('discription'));
const [nid,setid]=useState(notedata.length);

useEffect(() => {
  
   settitle(navigation.getParam('title'));
  setdiscription(navigation.getParam('discription'));
  setid(notedata.length+1);
console.log(ntitle);
console.log(ndiscription);


})

useEffect(()=>{
  if(ntitle!=null){
    addtasks();
   }

},[ntitle])


const handler=()=>{
  
  
 navigation.navigate('AddList');
  console.log("key press1");
  setid(nid);
 
}



const addtasks=()=>{
  const newTasks = [...notedata,{ title:ntitle,id:nid, discription:ndiscription}];
  setnote(newTasks);
  console.log(newTasks);
 
}




const renderArticles = () => {
  if (notedata.length > 0) {
      return (<FlatList
          data={notedata}
          renderItem={({ item,index }) => <View style={Styles.view2}index={notedata.length - 1 - index}><Text style={Styles.title}>{item.title}</Text><Text style={Styles.discription}>{item.discription}</Text>
          
          <TouchableOpacity style={Styles.dbutton} onPress={()=>{removeTask(index)}}><Text style={Styles.dbuttonText}>Delete</Text></TouchableOpacity>
          </View>}
         keyExtractor={item => item.id.toString()}

          initialNumToRender={5}
      />)
  }

  else
            return (<Text style={Styles.ntext}>Nothing to display</Text>)

 
}
// const myfun=()=>{
//   if(ntitle!=null)
//   {
//     return (
      
      
//       <View style={Styles.view2}><Text style={Styles.title}>{navigation.getParam('title')}</Text><Text style={Styles.discription}>{navigation.getParam('discription')}</Text>
//           <TouchableOpacity style={Styles.dbutton} onPress={()=>{removeTask(nid)}}><Text style={Styles.dbuttonText}>Delete</Text></TouchableOpacity>
//           </View>
//     )
      
      
      
//       // <View>
//       // <Text>--------------------------------------------</Text>

//       //  <Text>{navigation.getParam('title')}
//       //  {navigation.getParam('discription')}
      
//       //  </Text>
//       //  </View>)
//     }

// }




  return (
    <View style={Styles.view}>
          

            <SafeAreaView>
              <TouchableOpacity style={Styles.abutton} onPress={handler}><Text style={Styles.abuttonText}>Add Note</Text></TouchableOpacity>
            {renderArticles()}
            </SafeAreaView>
           
            
                  
              {/* <ScrollView>
                {notedata.map((item,key)=>(
                  <View item={item} key={key}><Text>{item.title}</Text><Text>{item.discription}</Text>
                    <Button title="Delete" onPress={()=>{removeTask(key)}}></Button>
                  </View>
                   



                ))}
              </ScrollView> */}
         
               


    </View>
  );
}
const Styles=StyleSheet.create({
  view:{
    flex:1,
   borderWidth: 4,
   padding:3,
   borderRadius:30,
   padding:8,
   margin:4,
   backgroundColor:'#484848'
   
  },
  view2:{

    flex:1,
    borderWidth: 4,
    padding:3,
    borderRadius:30,
    padding:8,
    margin:4,
    
    backgroundColor:'#debaba'

  },
  abutton:{
    backgroundColor: '#FF6347',
    padding:3,
    margin: 10,
    height: 70,
    alignSelf: 'flex-end',
    alignItems:'center',
    borderRadius:100,
    justifyContent: 'center',
  },
  abuttonText:{
    
    color: '#fff',
    

  },
  dbutton:{
    backgroundColor: '#FF6347',
      padding:3,
      margin: 5,
      height: 30,
      width: 60,
      alignSelf: 'flex-end',
      alignItems:'center',
      justifyContent: 'center',
      borderRadius:5
  },
  dbuttonText:{
    textAlign:'left',
    color:"white"

  },
  title:{
    color:"white",
    alignSelf:"center",
    fontWeight: 'bold',
    fontSize: 20,

  },
  discription:{
    padding:15,
    alignSelf:"center",
  },
  ntext:{
    color:'#fff',
    alignSelf:"center",
    fontWeight: 'bold',
    fontSize: 20,
    marginTop:200

  }
})
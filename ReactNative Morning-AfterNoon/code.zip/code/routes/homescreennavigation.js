import React from 'react';
import {createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import Login from '../screens/login/index';
import Dashboard from '../screens/dashboard/index';
import AddList from '../screens/addnote/index';
const Screens={
    Home:{
        screen:Login
    },
    AddList:{
        screen:AddList
    },
    Dashboard:{
        screen:Dashboard
    }
    

};

const HomeStack=createStackNavigator(Screens);

export default createAppContainer(HomeStack);